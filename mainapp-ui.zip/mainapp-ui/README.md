# Getting Started with Create React App

### Clone repository

```sh
//open your folder with cmd
git clone LINK
```

### Installing packeges

```sh
//open project folder with cmd
npm i
```

### Launch application

```sh
//open project folder with cmd
npm start
```
