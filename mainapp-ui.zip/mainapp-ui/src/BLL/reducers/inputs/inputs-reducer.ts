import { createSlice, PayloadAction } from "@reduxjs/toolkit";

export interface InputsStateType {
    name: string,
    surname: string,
    phone: string,
    birth_date: string,
}

const initialState = {
    name: '',
    surname: '',
    phone: '',
    birth_date: ''
} as InputsStateType

const InputsReducer = createSlice({
    name: 'inputs',
    initialState: initialState,
    reducers: {
        changeName(state, action: PayloadAction<string>) {
            state.name = action.payload
        },
        changeSurname(state, action: PayloadAction<string>) {
            state.surname = action.payload
        },
        changePhone(state, action: PayloadAction<string>) {
            state.phone = action.payload
        },
        changeBirthDate(state, action: PayloadAction<string>) {
            state.birth_date = action.payload
        }
    }
})

export const { changeName, changeSurname, changePhone, changeBirthDate } = InputsReducer.actions
export default InputsReducer.reducer