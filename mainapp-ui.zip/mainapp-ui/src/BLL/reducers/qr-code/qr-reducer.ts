import { createSlice, PayloadAction } from "@reduxjs/toolkit";

export interface QRcodeStateType {
    qrcode: string
}

const initialState = {
    qrcode: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
} as QRcodeStateType

const QRReducer = createSlice({
    name: 'inputs',
    initialState: initialState,
    reducers: {
        chandeQR(state, action: PayloadAction<string>) {
            state.qrcode = action.payload
        }
    }
})

export const { chandeQR } = QRReducer.actions
export default QRReducer.reducer