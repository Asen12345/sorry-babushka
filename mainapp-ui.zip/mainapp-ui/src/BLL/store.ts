import { configureStore } from '@reduxjs/toolkit'
import { useDispatch } from 'react-redux'
import InputsReducer from './reducers/inputs/inputs-reducer'
import QRReducer from './reducers/qr-code/qr-reducer'

const store = configureStore({
    reducer: {
        InputsReducer,
        QRReducer
    }
})

export type AppDispatch = typeof store.dispatch
export const useAppDispatch = () => useDispatch<AppDispatch>()
export type RootState = ReturnType<typeof store.getState>

export default store