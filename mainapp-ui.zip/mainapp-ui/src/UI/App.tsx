import React, { FC } from 'react';
import { BrowserRouter, Redirect, Route, Switch } from 'react-router-dom';
import Sign from './pages/sign/sign';
import './assets/global-styles/null-styles.scss'
import SignOut from './pages/sign-out/sign-out';
import { Provider } from 'react-redux'
import store from '../BLL/store';

const App: FC = () => {
    return (
        <Provider store={store}>
            <BrowserRouter>
                <Switch>
                    <Route path='/sign'>
                        <Sign />
                    </Route>
                    <Route path='/signout'>
                        <SignOut />
                    </Route>
                    <Route path='*'>
                        <Redirect to='/sign' />
                    </Route>
                </Switch>
            </BrowserRouter>
        </Provider>
    );
};

export default App;