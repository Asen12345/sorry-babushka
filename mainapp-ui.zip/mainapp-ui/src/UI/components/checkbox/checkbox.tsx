import React, { FC, useState } from 'react';
import styles from './styles.module.scss'
import CheckboxIcon from '../../assets/images/checkbox.svg'

const Checkbox: FC = () => {
    const [checked, setChecked] = useState<boolean>(true)

    return (
        <div onClick={() => setChecked(!checked)} className={styles.checkbox}>
            <img style={{ display: `${checked ? 'block' : 'none'}` }} className={styles.image} src={CheckboxIcon} alt="checkbox" />
        </div>
    );
};

export default Checkbox;