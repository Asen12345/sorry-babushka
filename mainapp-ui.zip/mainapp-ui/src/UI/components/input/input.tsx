import React, { FC } from 'react';
import ReactInputMask from 'react-input-mask';
import styles from './styles.module.scss'

interface PropsType {
    placeholder: string
    className: string
    onChange: Function
    value: string
    mask?: string
}

export const Input: FC<PropsType> = ({ placeholder, className, onChange, value }) => {
    return (
        <input maxLength={40} value={value} onChange={(e: React.ChangeEvent<HTMLInputElement>) => onChange(e)} className={`${styles.input} ${className}`} placeholder={placeholder} />
    );
};

export const MaskedInput: FC<PropsType> = ({ placeholder, className, onChange, value, mask = '' }): any => {
    return <ReactInputMask mask={mask} maxLength={40} onChange={(e: React.ChangeEvent<HTMLInputElement>) => onChange(e)} className={`${styles.input} ${className}`} placeholder={placeholder} />
}
