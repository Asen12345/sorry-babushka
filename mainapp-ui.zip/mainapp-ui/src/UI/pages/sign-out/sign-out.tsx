import React, { FC } from 'react';
import styles from './styles.module.scss'
import { NavLink } from 'react-router-dom';
import QRCode from 'qrcode.react'
import LogoImage from './../../assets/images/logo-2.png'
import InstagramIcon from './../../assets/images/instagram.svg'
import GoogleWalletICon from './../../assets/images/google-wallet.png'
import AppleWalletICon from './../../assets/images/apple-wallet.png'
import { useSelector } from 'react-redux';
import { RootState } from '../../../BLL/store';
import { QRcodeStateType } from '../../../BLL/reducers/qr-code/qr-reducer';

const SignOut: FC = () => {
    const { qrcode } = useSelector<RootState, QRcodeStateType>(store => store.QRReducer)

    return (
        <>
            <header className={styles.header}>
                <h1 className={styles.header__title}>ВАША КАРТА ГОТОВА</h1>
                <img className={styles.header__logo} src={LogoImage} alt="logo" />
            </header>
            <main className={styles.main}>
                <h2 className={styles.main__title}>Просканируйте QR-код и хроните свою карту в телефоне</h2>
                <div className={styles.qrcode_block}>
                    <QRCode size={180} value={qrcode} />
                </div>
                <div className={styles.addToWallet}>
                    <button className={styles.googleWallet}>
                        <img src={GoogleWalletICon} alt="google-wallet" />
                        <span>Сохранить на телефон</span>
                    </button>
                    <button className={styles.appleWallet}>
                        <img src={AppleWalletICon} alt="apple-wallet" />
                        <span>Добавить в Apple Wallet</span>
                    </button>
                </div>
            </main>
            <footer className={styles.footer}>
                <div className={styles.footer__menu}>
                    <div>
                        <h4 className={styles.footer__title}>Карта сайта</h4>
                        <div className={styles.footer__menu__links}>
                            <NavLink className={styles.footer__link} to='/main' >Главная</NavLink>
                            <NavLink className={styles.footer__link} to='/about' >О нас</NavLink>
                            <NavLink className={styles.footer__link} to='/contacts' >Контакты</NavLink>
                        </div>
                    </div>
                    <div className={styles.footer__contact_us}>
                        <h4 className={styles.footer__title}>Связаться с нами</h4>
                        <a className={styles.footer__link} href="1">+7 985 060-65-02</a>
                        <a href="1" className={styles.instagram_link}>
                            <img className={styles.instagram_icon} src={InstagramIcon} alt="instagram" />
                        </a>
                    </div>
                </div>
                <div className={styles.copyright}>
                    <span>©2021 «Sorry Бабушка»</span>
                </div>
            </footer>
        </>
    );
};

export default SignOut;