import React, { FC, useState, useEffect } from 'react';
import axios from 'axios';
import { NavLink } from 'react-router-dom';
import Button from '../../components/button/button';
import Checkbox from '../../components/checkbox/checkbox';
import { Input, MaskedInput } from '../../components/input/input';
import styles from './styles.module.scss'
import LogoImage from './../../assets/images/logo.png'
import InstagramIcon from './../../assets/images/instagram.svg'
import { useAppDispatch, RootState } from '../../../BLL/store';
import { changeBirthDate, changeName, changePhone, changeSurname, InputsStateType } from '../../../BLL/reducers/inputs/inputs-reducer';
import { useSelector } from 'react-redux';
import Cookies from 'js-cookie';
import { useHistory } from "react-router-dom";
/*
import PhoneValidation from '../../utils/phone-validation';
import BirthDayValidation from '../../utils/BirthDay-validation';
*/
import { checkIsText } from '../../utils/checkIsText';
import { transcode } from 'buffer';


const Sign: FC = () => {
    let history = useHistory();
    const dispatch = useAppDispatch()
    const { name, surname, phone, birth_date } = useSelector<RootState, InputsStateType>(store => store.InputsReducer)

    const checkName = (text: string) => {
        if (checkIsText(text[text.length - 1])) {
            dispatch(changeName(text))
        }
    }

    const checkSurname = (text: string) => {
        if (checkIsText(text[text.length - 1])) {
            dispatch(changeSurname(text))
        }
    }

    const submitForm = (e: any) => {
        e.preventDefault();
        var csrf = String(Cookies.get('csrftoken'))
        axios({
            method: 'POST',
            headers: {
                'Content-type': 'application/json',
                'X-CSRFToken': csrf,
            },
            url: 'http://127.0.0.1:8000/api/user-create/',
            data: {
                name: name,
                second_name: surname,
                phone: phone,
                date: birth_date,
            }
        }).then(response => {
            console.log('success');
        })
    }


    return (
        <>
            <header className={styles.header}>
                <h1 className={styles.header__title}>КАРТА ПОСТОЯННОГО ГОСТЯ</h1>
                <img className={styles.header__logo} src={LogoImage} alt="logo" />
            </header>
            <main className={styles.main}>
                <h2 className={styles.main__title}>Пожалуйста, заполните информацию перед путешествием</h2>
                <form className={styles.main__form} onSubmit={(e) => {submitForm(e)}}>
                    <Input value={name} onChange={(e: React.ChangeEvent<HTMLInputElement>) => { checkName(e.target.value) }} className={styles.data_input} placeholder='Имя' />
                    <Input value={surname} onChange={(e: React.ChangeEvent<HTMLInputElement>) => { checkSurname(e.target.value) }} className={styles.data_input} placeholder='Фамилия' />
                    <MaskedInput mask="\+7 (999) 999 99 99" value={phone} onChange={(e: React.ChangeEvent<HTMLInputElement>) => { dispatch(changePhone(e.target.value)) }} className={styles.data_input} placeholder='Телефон' />
                    <MaskedInput mask="99.99.9999" value={birth_date} onChange={(e: React.ChangeEvent<HTMLInputElement>) => { dispatch(changeBirthDate(e.target.value)) }} className={styles.data_input} placeholder='Дата рождения' />
                    <div className={styles.main__form__checkboxBlock}>
                        <Checkbox />
                        <span className={styles.main__form__text}>Я принимаю условия пользовательского соглашения</span>
                    </div>
                    <Button>Отправить форму</Button>
                </form>
            </main>
            <footer className={styles.footer}>
                <div className={styles.footer__menu}>
                    <div>
                        <h4 className={styles.footer__title}>Карта сайта</h4>
                        <div className={styles.footer__menu__links}>
                            <NavLink className={styles.footer__link} to='/main' >Главная</NavLink>
                            <NavLink className={styles.footer__link} to='/about' >О нас</NavLink>
                            <NavLink className={styles.footer__link} to='/contacts' >Контакты</NavLink>
                        </div>
                    </div>
                    <div className={styles.footer__contact_us}>
                        <h4 className={styles.footer__title}>Связаться с нами</h4>
                        <a href="tel:+7 985 060-65-02" className={styles.footer__link}>+7 985 060-65-02</a>
                        <a rel="noreferrer" target='_blank' href="https://www.instagram.com/sorrybabushka_family/" className={styles.instagram_link}>
                            <img className={styles.instagram_icon} src={InstagramIcon} alt="instagram" />
                        </a>
                    </div>
                </div>
                <div className={styles.copyright}>
                    <span>©2021 «Sorry Бабушка»</span>
                </div>
            </footer>
        </>
    );
};

export default Sign;