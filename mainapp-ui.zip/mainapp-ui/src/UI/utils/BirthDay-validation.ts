const BirthDayValidation = (text: string): boolean => {
    return true
}

export default BirthDayValidation