export const checkIsText = (text: string): boolean => {
    debugger
    return !Number.isInteger(Number(text)) && typeof text === "string" 
} 