const PhoneValidation = (text: string): boolean => {
    const regular: RegExp = /[787]\d{10}/
    return regular.test(text)
}

export default PhoneValidation